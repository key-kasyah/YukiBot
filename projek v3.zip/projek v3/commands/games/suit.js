// commands/games/suit.js
import yukiManager from '../../managers/yukiManager.js';
import ui from '../../utils/ui.js';

const suitCommand = {
    name: 'suit',
    description: 'Bermain suit (batu, gunting, kertas) dengan bot.',
    category: 'games',
    async execute({ sock, m, args }) {
        const choices = ['batu', 'gunting', 'kertas'];
        const userChoice = args[0]?.toLowerCase();
        const bet = parseInt(args[1]);
        const senderId = m.key.participant || m.key.remoteJid;

        if (!userChoice || !choices.includes(userChoice) || !bet || bet <= 0) {
            return await sock.sendMessage(m.key.remoteJid, { text: 'Format salah!\nContoh: *!suit kertas 100*' });
        }

        if (!yukiManager.subtractYuki(senderId, bet)) {
            return await sock.sendMessage(m.key.remoteJid, { text: `Yuki kamu tidak cukup untuk bertaruh ${bet}!` });
        }

        const botChoice = choices[Math.floor(Math.random() * choices.length)];
        let result = '';
        let prize = 0;

        if (userChoice === botChoice) {
            result = 'draw';
            prize = bet; // Kembalikan taruhan
        } else if (
            (userChoice === 'batu' && botChoice === 'gunting') ||
            (userChoice === 'gunting' && botChoice === 'kertas') ||
            (userChoice === 'kertas' && botChoice === 'batu')
        ) {
            result = 'win';
            prize = bet * 2; // Menang 2x lipat
        } else {
            result = 'lose';
            prize = 0; // Kalah
        }
        
        if (prize > 0) {
            yukiManager.addYuki(senderId, prize);
        }

        const resultMessage = ui.formatSuitResult(userChoice, botChoice, result);
        const finalYuki = yukiManager.getYuki(senderId);
        await sock.sendMessage(m.key.remoteJid, { text: `${resultMessage}\n\nKamu ${result === 'win' ? `memenangkan ${prize}` : result === 'draw' ? `mendapatkan kembali ${prize}`: 'kehilangan'} Yuki.\n💰 Yuki kamu sekarang: *${finalYuki}*` }, { quoted: m });
    }
};

export default suitCommand;