// managers/statsManager.js
import fs from 'fs';
const DB_PATH = './users.json';

// --- FUNGSI DATABASE (dideklarasikan sekali di atas) ---
function readDB() {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
}

function writeDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}
// --- AKHIR FUNGSI DATABASE ---

function checkStats(userObject) {
    if (userObject.cf_plays === undefined) userObject.cf_plays = 0;
    if (userObject.cf_wins === undefined) userObject.cf_wins = 0;
    if (userObject.roulette_plays === undefined) userObject.roulette_plays = 0;
    if (userObject.roulette_winnings === undefined) userObject.roulette_winnings = 0;
}

const statsManager = {
    updateCoinflipStats: (userId, didWin) => {
        const db = readDB();
        if (!db[userId]) return;
        checkStats(db[userId]);
        
        db[userId].cf_plays += 1;
        if (didWin) {
            db[userId].cf_wins += 1;
        }
        
        writeDB(db);
    },

    getCoinflipStats: (userId) => {
        const db = readDB();
        if (!db[userId]) return null;
        checkStats(db[userId]);
        return {
            plays: db[userId].cf_plays,
            wins: db[userId].cf_wins
        };
    },

    getCoinflipRank: () => {
        const db = readDB();
        const users = Object.keys(db).map(userId => {
            const user = db[userId];
            checkStats(user);
            const winrate = user.cf_plays > 0 ? (user.cf_wins / user.cf_plays) * 100 : 0;
            return { id: userId, wins: user.cf_wins, plays: user.cf_plays, winrate: winrate };
        });
        users.sort((a, b) => b.wins - a.wins);
        return users.slice(0, 5);
    },

    updateRouletteStats: (userId, totalWinnings) => {
        const db = readDB();
        if (!db[userId]) return;
        checkStats(db[userId]);
        
        db[userId].roulette_plays += 1;
        db[userId].roulette_winnings += totalWinnings;
        
        writeDB(db);
    },

    getRouletteStats: (userId) => {
        const db = readDB();
        if (!db[userId]) return null;
        checkStats(db[userId]);
        return {
            plays: db[userId].roulette_plays,
            winnings: db[userId].roulette_winnings
        };
    },

    getRouletteRank: () => {
        const db = readDB();
        const users = Object.keys(db).map(userId => {
            const user = db[userId];
            checkStats(user);
            return { id: userId, plays: user.roulette_plays, winnings: user.roulette_winnings };
        });
        users.sort((a, b) => b.winnings - a.winnings);
        return users.slice(0, 5);
    }
};

export default statsManager;